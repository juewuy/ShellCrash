import{V as a,b3 as m}from"./index-DaTMMU6E.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
