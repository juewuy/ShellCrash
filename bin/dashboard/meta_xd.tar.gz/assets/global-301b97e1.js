import{Y as a}from"./vendor-9950b998.js";import{a8 as m}from"./index-6a446918.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
