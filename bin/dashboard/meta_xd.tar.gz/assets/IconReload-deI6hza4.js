import{N as o}from"./index-CvtbhWKk.js";/**
 * @license @tabler/icons-solidjs v3.19.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var e=o("outline","reload","IconReload",[["path",{d:"M19.933 13.041a8 8 0 1 1 -9.925 -8.788c3.899 -1 7.935 1.007 9.425 4.747"}],["path",{d:"M20 4v5h-5"}]]);export{e as I};
