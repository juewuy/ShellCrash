import{f as t,bA as r}from"./index-CJjWLc9u.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
