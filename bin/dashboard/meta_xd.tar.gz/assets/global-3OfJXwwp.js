import{a5 as a,a_ as m}from"./index-B3l_s7jA.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
