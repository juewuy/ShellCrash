import{W as a,b4 as m}from"./index-S9M5po7B.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
