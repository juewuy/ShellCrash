import{_ as a}from"./vendor-0f159d83.js";import{a8 as m}from"./index-26b8b771.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
