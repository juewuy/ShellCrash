import{f as t,bA as r}from"./index-CtVw7BLk.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
