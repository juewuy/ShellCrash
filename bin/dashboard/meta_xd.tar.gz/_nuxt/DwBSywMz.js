import{c as e}from"./qqqfUOwc.js";var t=e("outline","x","X",[["path",{d:"M18 6l-12 12",key:"svg-0"}],["path",{d:"M6 6l12 12",key:"svg-1"}]]);export{t as I};
